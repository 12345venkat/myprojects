<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $orderDate = $_POST["order_date"];
    $company = $_POST["company"];
    $owner = $_POST["owner"];
    $item = $_POST["item"];
    $quantity = $_POST["quantity"];
    $weight = $_POST["weight"];
    $trackingID = $_POST["tracking_id"];
    $shipmentSize = $_POST["shipment_size"];
    $boxCount = $_POST["box_count"];
    $specification = $_POST["specification"];
    $checklist = $_POST["checklist"];
    $additionalQuantity = $_POST["quantity2"];

    
    $patternAlpha = "/^[A-Za-z]+$/";
    $patternNumeric = "/^[0-9]+$/";
    $patternAlphanumeric = "/^[A-Za-z0-9]+$/";
    $patternInteger = "/^-?\d+$/";
    $patternFloat = "/^-?\d+(?:\.\d+)?$/";

    
    $validationMessages = [
        "order_date" => "Please enter a valid date.",
        "company" => "Please enter alphabetic characters only in Company.",
        "owner" => "Please enter alphabetic characters only in owner.",
        "item" => "Please enter alphanumeric characters only in item.",
        "quantity" => "Please enter an integer in quantity .",
        "weight" => "Please enter a float in weight.",
        "request_shipment" => "Please enter alphabetic characters only in request_shipment.",
        "tracking_id" => "Please enter alphanumeric characters only in tracking_id.",
        "shipment_size" => "Please enter dimensions in the format 'LxBxH' in shipment_size.",
        "box_count" => "Please enter an integer in box_count.",
        "specification" => "Please enter a string in specification .",
        "checklist" => "Please enter a string in checklist.",
        "additional_quantity" => "Please enter a string in additional_quantity."
    ];

   
    $errors = [];
    if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $orderDate)) {
        $errors["order_date"] = $validationMessages["order_date"];
    }
    if (!preg_match($patternAlpha, $company)) {
        $errors["company"] = $validationMessages["company"];
    }
    if (!preg_match($patternAlpha, $owner)) {
        $errors["owner"] = $validationMessages["owner"];
    }
    if (!preg_match($patternAlphanumeric, $item)) {
        $errors["item"] = $validationMessages["item"];
    }
    if (!preg_match($patternInteger, $quantity)) {
        $errors["quantity"] = $validationMessages["quantity"];
    }
    if (!preg_match($patternFloat, $weight)) {
        $errors["weight"] = $validationMessages["weight"];
    }
    
    if (!preg_match($patternAlphanumeric, $trackingID)) {
        $errors["tracking_id"] = $validationMessages["tracking_id"];
    }
    if (!preg_match("/^\d+(?:x\d+){2}$/i", $shipmentSize)) {
        $errors["shipment_size"] = $validationMessages["shipment_size"];
    }
    if (!preg_match($patternInteger, $boxCount)) {
        $errors["box_count"] = $validationMessages["box_count"];
    }
    if (!is_string($specification)) {
        $errors["specification"] = $validationMessages["specification"];
    }
    if (!is_string($checklist)) {
        $errors["checklist"] = $validationMessages["checklist"];
    }
    if (!is_string($additionalQuantity)) {
        $errors["additional_quantity"] = $validationMessages["additional_quantity"];
    }

    if (count($errors) === 0) {
        $hostname = 'localhost';     
$username = 'root'; 
$password = ''; 
$database = 'intern'; 

try {
    $dsn = "mysql:host=$hostname;dbname=$database;charset=utf8mb4";
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Database connection established successfully.";
} catch (PDOException $e) {
    echo "Failed to connect to the database: " . $e->getMessage();
}
        
        $orderDate = $_POST['order_date'];
        $company = $_POST['company'];
        $owner = $_POST['owner'];
        $item = $_POST['item'];
        $quantity = $_POST['quantity'];
        $weight = $_POST['weight'];
        $requestOfShipment = "";
        $trackingID = $_POST['tracking_id'];
        $shipmentSize = $_POST['shipment_size'];
        $boxCount = $_POST['box_count'];
        $specification = $_POST['specification'];
        $checklist = $_POST['checklist'];
        $quantity2 = $_POST['quantity2'];
        
        $sql = "INSERT INTO orders (order_date, company, owner, item, quantity, weight, request_of_shipment, tracking_id, shipment_size, box_count, specification, checklist, quantity2)
                VALUES (:order_date, :company, :owner, :item, :quantity, :weight, :requestOfShipment, :tracking_id, :shipment_size, :box_count, :specification, :checklist, :quantity2)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'order_date' => $orderDate,
            'company' => $company,
            'owner' => $owner,
            'item' => $item,
            'quantity' => $quantity,
            'weight' => $weight,
            'requestOfShipment' => $_POST["requestOfShipment"],
            'tracking_id' => $trackingID,
            'shipment_size' => $shipmentSize,
            'box_count' => $boxCount,
            'specification' => $specification,
            'checklist' => $checklist,
            'quantity2' => $quantity2
        ]);
        
        if ($stmt->rowCount() > 0) {
            echo "Form data has been stored in the database.";
        } else {
            echo "Error storing form data in the database.";
        }
       
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Order Form</title>
    <style>
form {
  display: flex;
  flex-direction: column;
  max-width: 400px; 
}

label {
  margin-bottom: 10px;
}

input[type="submit"] {
  margin-top: 10px;
}
</style>
</head>
<body>
    <h1>Order Form</h1>
    <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && count($errors) > 0) { ?>
        <ul>
            <?php foreach ($errors as $field => $message) { ?>
                <li><?php echo $message; ?></li>
            <?php } ?>
        </ul>
    <?php } ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
       
        <label for="order_date">Order Date:</label>
        <input type="date" name="order_date" id="order_date" required>

        <label for="company">Company:</label>
        <input type="text" name="company" id="company" required>

        <label for="owner">Owner:</label>
        <input type="text" name="owner" id="owner" required>

        <label for="item">Item:</label>
        <input type="text" name="item" id="item" required>

        <label for="quantity">Quantity:</label>
        <input type="text" name="quantity" id="quantity" required>

        <label for="weight">Weight:</label>
        <input type="text" name="weight" id="weight" required>

        <label for="request_shipment">Request of Shipment:</label>
        <input type="text" name="requestOfShipment" id="requestOfShipment" required>

        <label for="tracking_id">Tracking ID:</label>
        <input type="text" name="tracking_id" id="tracking_id" required>

        <label for="shipment_size">Shipment Size:</label>
        <input type="text" name="shipment_size" id="shipment_size" required>

        <label for="box_count">Box Count:</label>
        <input type="text" name="box_count" id="box_count" required>

        <label for="specification">Specification:</label>
        <input type="text" name="specification" id="specification" required>

        <label for="checklist">Checklist:</label>
        <input type="text" name="checklist" id="checklist" required>

        <label for="additional_quantity">Additional Quantity:</label>
        <input type="text" name="quantity2" id="quantity2" required>

        <input type="submit" name="submit" value="Submit">
    </form>
</body>
</html>
