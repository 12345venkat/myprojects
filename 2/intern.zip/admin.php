

<?php
$host = 'localhost';
$dbname = 'intern';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

$query = "SELECT order_date, company, owner, item, quantity, weight, request_of_shipment, tracking_id, shipment_size, box_count, specification, checklist, quantity2 FROM orders";
$stmt = $conn->query($query);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);


if (count($orders) > 0) {
    echo "<table>";
    echo "<tr><th>Order Date</th><th>Company</th><th>Owner</th><th>Item</th><th>Quantity</th><th>Weight</th><th>Request of Shipment</th><th>Tracking ID</th><th>Shipment Size</th><th>Box Count</th><th>Specification</th><th>Checklist</th><th>Quantity2</th></tr>";
    
    foreach ($orders as $order) {
        echo "<tr>";
        echo "<td>" . $order['order_date'] . "</td>";
        echo "<td>" . $order['company'] . "</td>";
        echo "<td>" . $order['owner'] . "</td>";
        echo "<td>" . $order['item'] . "</td>";
        echo "<td>" . $order['quantity'] . "</td>";
        echo "<td>" . $order['weight'] . "</td>";
        echo "<td>" . $order['request_of_shipment'] . "</td>";
        echo "<td>" . $order['tracking_id'] . "</td>";
        echo "<td>" . $order['shipment_size'] . "</td>";
        echo "<td>" . $order['box_count'] . "</td>";
        echo "<td>" . $order['specification'] . "</td>";
        echo "<td>" . $order['checklist'] . "</td>";
        echo "<td>" . $order['quantity2'] . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
} else {
    echo "No orders found.";
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin page </title>
    <style>
        table {
  border-collapse: collapse;
  width: 100%;
}

table th,
table td {
  border: 1px solid #ccc;
  padding: 8px;
}

table th {
  background-color: #f2f2f2;
  font-weight: bold;
  text-align: left;
}

table tr:nth-child(even) {
  background-color: #f9f9f9;
}

table tr:hover {
  background-color: #e6e6e6;
}

    </style>
</head>
<body>
    
    
</body>
</html>